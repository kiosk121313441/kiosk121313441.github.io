KIOSK ZAHRAA ORIENT – FERTIGE WEBSITE

Dateien:
- index.html
- zahraa-orient-logo.jpg

Die hochgeladene Originalgrafik wurde unverändert als kleines Logo links oben eingebaut.

Enthalten:
- Dunkelrot/Weiß/Schwarz Design
- Responsive Darstellung für Handy und PC
- Über-uns-Bereich mit Geschichte seit 2016
- Angebot: Shisha, Tabak, Zubehör, Getränke, Snacks usw.
- DPD & GLS Paketshop mit Erfahrungstext
- Kontakttelefon 0157 31292710
- Adresse Bahnstr. 27, 47877 Willich
- Google-Maps-Button
- Hinweis auf tägliche Öffnung

Vor dem öffentlichen Einsatz sollten die tatsächlichen Öffnungszeiten und ein vollständiges Impressum/Datenschutzerklärung ergänzt bzw. geprüft werden.
